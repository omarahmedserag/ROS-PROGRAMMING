This repository is a companion resource for the Robot Programming module, CMP9767, at the University of Lincoln. You will find here details about the development environment enabling work with the robots, the description of practical tasks for each week, and practical instructions for the assignment.

## Workshops
For a list of all the workshops offered as part of CMP9767 and additional resources, please refer to the [Wiki](https://github.com/LCAS/CMP9767/wiki).
